#include <algorithm>
#include <iostream>
#include <vector>
#include <string>
#include <thread>

#include <windows.h>
#include <shlobj.h>
#include <propkey.h> 
#include <atlbase.h>

#include "apiprocess/process.hpp"

#define EXPORTED_FUNCTION extern "C" __declspec(dllexport)

enum {
  pKey_FileDescription,
  pKey_Software_ProductName,
  pKey_OriginalFileName,
  pKey_Company,
  pKey_Copyright
};

ngs::ps::NGS_PROCID BlacklistedProcessId = 0;

void MessagePump() {
  MSG msg;
  while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) {
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
}

std::wstring widen(std::string str) {
  if (str.empty()) return L"";
  std::size_t wchar_count = str.size() + 1;
  std::vector<wchar_t> buf(wchar_count);
  return std::wstring{ buf.data(), (std::size_t)MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, buf.data(), (int)wchar_count) };
}
  
std::string narrow(std::wstring wstr) {
  if (wstr.empty()) return "";
  int nbytes = WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), (int)wstr.length(), nullptr, 0, nullptr, nullptr);
  std::vector<char> buf(nbytes);
  return std::string { buf.data(), (std::size_t)WideCharToMultiByte(CP_UTF8, 0, wstr.c_str(), (int)wstr.length(), buf.data(), nbytes, nullptr, nullptr) };
}

BOOL IsRunAsAdministrator() {
  BOOL fIsRunAsAdmin = FALSE;
  DWORD dwError = ERROR_SUCCESS;
  PSID pAdministratorsGroup = nullptr;
  SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;
  if (!AllocateAndInitializeSid(&NtAuthority, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &pAdministratorsGroup)) {
    dwError = GetLastError();
    goto Cleanup;
  }
  if (!CheckTokenMembership(nullptr, pAdministratorsGroup, &fIsRunAsAdmin)) {
    dwError = GetLastError();
    goto Cleanup;
  }
 Cleanup:
  if (pAdministratorsGroup) {
    FreeSid(pAdministratorsGroup);
    pAdministratorsGroup = nullptr;
  }
  if (ERROR_SUCCESS != dwError) {
    throw dwError;
  }
  return fIsRunAsAdmin;
}

void ElevateNow() {
  BOOL bAlreadyRunningAsAdministrator = FALSE;
  try {
    bAlreadyRunningAsAdministrator = IsRunAsAdministrator();
  } catch (...) {
    std::cout << "Failed to determine if application was running with admin rights" << std::endl;
    DWORD dwErrorCode = GetLastError();
    TCHAR szMessage[256];
    _stprintf_s(szMessage, ARRAYSIZE(szMessage), _T("Error code returned was 0x%08lx"), dwErrorCode);
    std::cout << szMessage << std::endl;
  }
  if (!bAlreadyRunningAsAdministrator) {
    wchar_t szPath[MAX_PATH];
    if (GetModuleFileNameW(nullptr, szPath, MAX_PATH)) {
      SHELLEXECUTEINFOW sei = { sizeof(sei) };
      sei.lpVerb = L"runas";
      sei.lpFile = szPath;
      sei.lpParameters = PathGetArgsW(GetCommandLineW());
      sei.hwnd = nullptr;
      sei.nShow = SW_NORMAL;
      if (!ShellExecuteExW(&sei)) {
        DWORD dwError = GetLastError();
        if (dwError == ERROR_CANCELLED) {
          std::cout << "End user did not allow elevation" << std::endl;
          _exit(1);
        }
      } else {
        _exit(1);
      }
    }
  }
}

std::wstring GetVersionInfoFromWideExecutablePathName(std::wstring pPath, int pKey) {
  CComPtr<IShellItem2> pItem;
  HRESULT hr = SHCreateItemFromParsingName(pPath.c_str(), nullptr, IID_PPV_ARGS(&pItem));
  if (FAILED(hr)) return L"";
  CComHeapPtr<WCHAR> pValue;
  switch (pKey) {
   case pKey_FileDescription:
    hr = pItem->GetString(PKEY_FileDescription, &pValue);
  break;
   case pKey_Software_ProductName:
    hr = pItem->GetString(PKEY_Software_ProductName, &pValue);
  break;
   case pKey_OriginalFileName:
    hr = pItem->GetString(PKEY_OriginalFileName, &pValue);
  break;
   case pKey_Company:
    hr = pItem->GetString(PKEY_Company, &pValue);
  break;
   case pKey_Copyright:
    hr = pItem->GetString(PKEY_Copyright, &pValue);
  break;
   default:
    hr = pItem->GetString(PKEY_FileDescription, &pValue);
  break;
  }
  if (FAILED(hr)) return L"";
  return std::wstring(pValue);
}

std::wstring GetWideFileName(std::wstring pFileName) {
  std::size_t fp = pFileName.find_last_of(L"\\/");
  if (fp == std::wstring::npos) return pFileName;
  return pFileName.substr(fp + 1);
}

void GetBlacklistedProcIdByVersionInfo(int pKey, std::wstring pString) {
  std::transform(pString.begin(), pString.end(), pString.begin(), ::tolower);
  std::vector<ngs::ps::NGS_PROCID> list = ngs::ps::proc_id_enum();
  for (int i = 0; i < list.size(); i++) {
    MessagePump();
    std::wstring wexe = widen(ngs::ps::exe_from_proc_id(list[i]));
    std::wstring vers = GetVersionInfoFromWideExecutablePathName(wexe, pKey);
    std::transform(vers.begin(), vers.end(), vers.begin(), ::tolower);
    if (wcscmp(vers.c_str(), pString.c_str()) == 0) {
      BlacklistedProcessId = list[i];
      break;
    }
  }
}

void GetBlacklistedProcIdByExeFileName(std::wstring pFileName) {
  pFileName = GetWideFileName(pFileName);
  std::transform(pFileName.begin(), pFileName.end(), pFileName.begin(), ::tolower);
  std::vector<ngs::ps::NGS_PROCID> list = ngs::ps::proc_id_enum();
  for (int i = 0; i < list.size(); i++) {
    MessagePump();
    std::wstring wexe = widen(ngs::ps::exe_from_proc_id(list[i]));
    wexe = GetWideFileName(wexe);
    std::transform(wexe.begin(), wexe.end(), wexe.begin(), ::tolower);
    if (wcscmp(pFileName.c_str(), wexe.c_str()) == 0) {
      BlacklistedProcessId = list[i];
      break;
    }
  }
}

EXPORTED_FUNCTION double BlacklistProcIdByVersionInfo(double pKey, const char *pString) {
  HRESULT hr = CoInitialize(nullptr);
  std::wstring pWideString = widen(pString);
  // don't ask why this line is even needed; i don't know and it doesn't work without it:
  GetVersionInfoFromWideExecutablePathName(L"C:\\Windows\\System32\\cmd.exe", (int)pKey);
  std::thread(GetBlacklistedProcIdByVersionInfo, (int)pKey, pWideString).detach();
  return 0;
}

EXPORTED_FUNCTION double BlacklistProcIdByExeFileName(const char *pFileName) {
  std::wstring pWideFileName = widen(pFileName);
  std::thread(GetBlacklistedProcIdByExeFileName, pWideFileName).detach();
  return 0;
}

EXPORTED_FUNCTION double GetBlacklistedProcessId() {
  return BlacklistedProcessId;
}

EXPORTED_FUNCTION double FreeBlacklistedProcessId() {
  BlacklistedProcessId = 0;
  return 0;
}

EXPORTED_FUNCTION const char *GetVersionInfoFromExecutablePathName(const char *FileName, double pKey) {
  HRESULT hr = CoInitialize(nullptr);
  std::wstring wFileName = widen(FileName);
  static std::string result; 
  result = narrow(GetVersionInfoFromWideExecutablePathName(wFileName, (int)pKey));
  return result.c_str();
}

EXPORTED_FUNCTION double RunSelfAsAdmin() {
  if (IsRunAsAdministrator()) {
    std::cout << "The applicaiton is already running with admin privileges" << std::endl;
  } else {
    ElevateNow();
  }
  return 0;
}
